require.config({
    'packages': [
        {
            'name': 'eicons',
            'location': '../dep/eicons/1.0.0-beta.1/src',
            'main': 'main.less'
        },
        {
            'name': 'eoo',
            'location': '../dep/eoo/0.1.4/src',
            'main': 'main'
        },
        {
            'name': 'est',
            'location': '../dep/est/1.3.0/src'
        },
        {
            'name': 'etpl',
            'location': '../dep/etpl/3.0.1/src',
            'main': 'main'
        },
        {
            'name': 'jquery',
            'location': '../dep/jquery/1.9.1/src',
            'main': 'jquery.min'
        },
        {
            'name': 'moment',
            'location': '../dep/moment/2.7.0/src',
            'main': 'moment'
        },
        {
            'name': 'underscore',
            'location': '../dep/underscore/1.5.2/src',
            'main': 'underscore'
        },
        {
            'name': 'esf',
            'location': '../dep/esf/1.0.0-rc.1/src'
        },
        {
            'name': 'esui',
            'location': '../dep/esui/3.2.0-beta.1/src',
            'main': 'main'
        },
        {
            'name': 'ub-ria-ui',
            'location': '../dep/ub-ria-ui/1.0.0-beta.1/src'
        }
    ],
    'paths': {}
});