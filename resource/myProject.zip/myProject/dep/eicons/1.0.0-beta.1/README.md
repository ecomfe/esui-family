eicons
======

EICONS定义了图标规范。定义了图标的名称。可以选择多种font进行适配。默认提供[Font Awesome](http://fontawesome.io/icons/)的实现。

[DEMO](http://ecomfe.github.io/eicons/demo/demo.html)