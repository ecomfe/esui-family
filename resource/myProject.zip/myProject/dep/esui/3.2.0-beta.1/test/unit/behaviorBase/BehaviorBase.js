define(function (require) {
    var lib = require('esui/lib');
    var $ = require('jquery');

    describe('test', function () {


        it('default case', function () {
            
            expect(true).toBe(true);
        });
    });
});